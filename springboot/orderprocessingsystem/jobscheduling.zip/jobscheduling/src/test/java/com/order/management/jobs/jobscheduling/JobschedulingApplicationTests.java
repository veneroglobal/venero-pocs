package com.order.management.jobs.jobscheduling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobschedulingApplicationTests {

	@Test
	void contextLoads() {
	}

}
