package com.order.management.jobs.jobscheduling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobschedulingApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobschedulingApplication.class, args);
	}

}
